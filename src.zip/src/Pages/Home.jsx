import React from 'react'
import LeftNav from '../Components/LeftNav'
import Login from '../Components/Login'
import Signup from '../Components/Signup'
import Courses from './Courses'
import AddCourse from '../Components/AddCourse'


const Home = () => {
  return (
    <>
       {/* <LeftNav/>     */}
       {/* <Login/> */}
       {/* <Signup/> */}
       <Courses/>
       {/* <AddCourse/> */}
    </>
  )
}

export default Home