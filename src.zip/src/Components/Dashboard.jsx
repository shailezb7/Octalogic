// src/components/Dashboard.js
import React from 'react';

function Dashboard() {
  return (
    <div>
      <h2>Music School Dashboard</h2>
      {/* Add your dashboard components and tables here */}
    </div>
  );
}

export default Dashboard;
